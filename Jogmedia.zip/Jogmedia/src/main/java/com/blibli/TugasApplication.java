package com.blibli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TugasApplication {

	public static void main(String[] args) {
		SpringApplication.run(TugasApplication.class, args);
	}
}
